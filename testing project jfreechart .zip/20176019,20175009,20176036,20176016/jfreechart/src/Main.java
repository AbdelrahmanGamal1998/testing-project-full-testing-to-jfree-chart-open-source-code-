import org.jfree.data.xy.MatrixSeries;
import org.jfree.util.SortOrder;
import org.jfree.data.KeyedValueComparator;
import org.jfree.data.KeyedValueComparatorType;
public class Main {

    public static void main(String[] args) {
    	//DefaultKeyedValues DefaultKeyedValues =new DefaultKeyedValues();
    	  //System.out.println(DefaultKeyedValues.getKeys());
        MatrixSeries m=new MatrixSeries("M1",2,3);
        m.update(1,1,12);
        System.out.println(m.getItem(4));
        KeyedValueComparatorType type;

 	   
	     SortOrder order = null;
	
	    
/*KeyedValueComparator keyedValueComparator = new KeyedValueComparator(KeyedValueComparatorType.BY_KEY,order.ASCENDING);

        Object o2=new Object();
  	  Object o1=new Object();
      int a = keyedValueComparator.compare(o1, o2);	
      System.out.println(a);
*/
    }
    
}
